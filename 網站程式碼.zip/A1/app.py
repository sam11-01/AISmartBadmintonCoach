import functools
import os
import re
import uuid
import pymysql
# 載入 Flask相關
from flask import Flask, render_template, request, redirect, url_for, session, g, flash, send_from_directory, send_file, jsonify, json, after_this_request
from dataclasses import dataclass
from werkzeug.utils import secure_filename
from functools import wraps
#資料庫
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import ForeignKey
from sqlalchemy import text
from sqlalchemy.sql.expression import func
from sqlalchemy import func
from sqlalchemy import Sequence
from sqlalchemy.orm import relationship
# from flask_mail import Mail, Message
from itsdangerous import URLSafeTimedSerializer
import subprocess
from Long_Video import Long
from LongBackHand_Video import LongBackHand
from Short_Video import Short
from BackHandFlick_Video import BackHandFlick
from ForeHandFlick_Video import ForeHandFlick

# Flask 類別 初始化時 傳入的 __name__ 參數，代表當前模組的名稱。是固定用法，以便讓 Flask 知道在哪裡尋找資源。
app = Flask(__name__)
# 用於加密 session 資訊
app.config['SECRET_KEY'] = "xxxxxxx"

# SQL
# 設定資料庫連接地址
# MySQL
DB_URI_1  = "mysql+pymysql://root:root@localhost:3306/db_badminton"
# SQLite
# DB_URI_1  = "sqlite:///db_badminton.db"

app.config['SQLALCHEMY_DATABASE_URI'] = DB_URI_1

# 是否追蹤資料庫修改，一般不開啟, 會影響效能
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
# 是否顯示底層執行的SQL語句
app.config['SQLALCHEMY_ECHO'] = True
#初始化組件物件, 直接關聯Flask應用
db = SQLAlchemy(app)

# 定義User模型
class User(db.Model):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(100), unique=True, nullable=False, index=True)
    password = db.Column(db.String(255), nullable=False)
    def __init__(self, username, password):
        self.username = username
        self.password = password

# 定義Player模型
class Player(db.Model):
    __tablename__ = 'player'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    name = db.Column(db.String(100))
    shot = db.Column(db.String(100))
    training_progress = db.Column(db.Integer)
    complete_progress = db.Column(db.Integer)
    percentage = db.Column(db.Float)
    date = db.Column(db.TIMESTAMP, nullable=True, default=None)

    # 定義與User模型的關係
    user = relationship('User', backref='players')

#檔案上傳的路徑
UPLOAD_FOLDER = './static/uploads'
# 允許上傳的檔案類型 # 限制檔案的格式
ALLOWED_EXTENSIONS = set(['mp4', 'avi', 'mov', 'wmv', 'flv', 'mkv', 'ogg','avc', 'avchd', 'mjpg', 'mpg', 'mpeg'])
# 設置static目錄路徑
static_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), './static/uploads')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# 1 # 驗證上傳的檔案是否符合允許的檔案格式
def allowed_file(filename):
    _, file_extension = os.path.splitext(filename)
    return file_extension[1:].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def home():     # 發出請求後會執行 home() 的函式
    return render_template('home.html')     # 執行函式後會回傳特定的網頁內容


@app.before_request
def before_request():
    g.user = None
    if 'username' in session:
        user = User.query.filter_by(username=session['username']).first()
        if user:
            g.user = user

@app.after_request
def add_header(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    return response

def login_required(view):
    @wraps(view)
    def wrapped_view(*args, **kwargs):
        if g.user is None:
            return redirect(url_for('login'))  # 重新導向至登入頁面
        return view(*args, **kwargs)
    return wrapped_view

# 註冊
@app.route("/register", methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        repassword = request.form.get('repassword')
        # 檢查帳號名是否已存在
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            return '帳號已被註冊'
        # 判斷兩次密碼是否一致並檢查是否有輸入帳號和密碼
        if password == repassword and password != '' and username != '':
            new_user = User(username=username, password=password)
            db.session.add(new_user)
            db.session.commit()
            return redirect('/login')
        return "兩次密碼不一致,或未輸入密碼"
    return render_template('register.html')

# 登入
@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        session.pop('username',None)
        username = request.form.get('username')
        password = request.form.get('password')
        user = User.query.filter_by(username=username, password=password).first()
        if user:
            g.user = user
            session['username'] = username
            return redirect('/schedule')
        else:
            return "登入失敗"
    return render_template('login.html')

# 登出
@app.route('/logout', methods=['POST', 'GET'])
def logout():
    session.pop('username', None)
    @after_this_request
    def add_header(response):
        response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
        return response
    return redirect('/login')

# 選單
@app.route('/menu', methods=['POST', 'GET'])
def menu():
    return render_template('menu.html')

# 系統使用說明
@app.route('/explanation', methods=['POST', 'GET'])
def explanation():
    return render_template('explanation.html')

# 影片範例
@app.route('/explanation_video', methods=['POST', 'GET'])
def explanation_video():
    return render_template('explanation_video.html')

# 進度表
@app.route('/schedule', methods=['POST', 'GET'])
def schedule():
    if g.user is None:
        return redirect(url_for('login'))  # 若 g.user 為空，導向到登入頁面

    #  获取当前登录用户的信息
    current_user = User.query.filter_by(username=session['username']).first()

    players = Player.query.filter_by(user_id=current_user.id).all()

    if request.method == 'POST':

        selected_id = request.form.get('selected_id')
        # 存在 selected_id，执行修改操作
        if selected_id:
            action = request.form.get('action')
            player = Player.query.get(selected_id)
            if player and player.user_id == current_user.id:
                if action == 'update':  # 如果是更新操作
                    player.name = request.form.get('name')
                    player.shot = request.form.get('shot')
                    # 如果使用者輸入的不是有效的整數，你的應用程式就會返回一條錯誤消息
                    try:
                        training_progress_str = request.form.get('training_progress')
                        complete_progress_str = request.form.get('complete_progress')

                        # 檢查輸入是否只包含數字
                        if not re.match("^[0-9]+$", training_progress_str) or not re.match("^[0-9]+$", complete_progress_str):
                            raise ValueError("Invalid input format. Please enter a valid number.")

                        # 如果檢查通過，再嘗試轉換為整數
                        training_progress = int(training_progress_str)
                        complete_progress = int(complete_progress_str)

                        player.training_progress = training_progress
                        player.complete_progress = complete_progress
                        player.percentage = round((player.complete_progress / player.training_progress) * 100, 2) if player.training_progress != 0 else 0

                        # player.date = request.form['date']
                        date = request.form.get('date')
                        if date:
                            player.date = date  # 設定日期
                        else:
                            # 處理日期為空的情況，例如傳回錯誤訊息
                            flash('Date is required for updates.', 'danger')
                            return redirect('/schedule')

                        db.session.commit()  # 提交更改，保存到数据库

                    except ValueError as e:
                        # 如果無法將字串轉換為整數，進行相應的處理，例如返回錯誤消息
                        flash(str(e), 'danger')
                        return redirect('/schedule')

                elif action == 'delete':  # 如果是删除操作
                    db.session.delete(player)
                    db.session.commit()
        # 不存在 selected_id，执行新增操作
        else:
            name = request.form.get('name')
            shot = request.form.get('shot')
            # 如果使用者輸入的不是有效的整數，你的應用程式就會返回一條錯誤消息
            try:
                training_progress_str = request.form.get('training_progress')
                complete_progress_str = request.form.get('complete_progress')

                # 檢查輸入是否只包含數字
                if not re.match("^[0-9]+$", training_progress_str) or not re.match("^[0-9]+$", complete_progress_str):
                    raise ValueError("Invalid input format. Please enter a valid number.")

                # 如果檢查通過，再嘗試轉換為整數
                training_progress = int(training_progress_str)
                complete_progress = int(complete_progress_str)

                percentage = round((complete_progress / training_progress) * 100, 2) if training_progress != 0 else 0
                # date = request.form['date']
                date = request.form.get('date')

                if date:
                    # 建立 Player 物件並關聯到 User
                    player = Player(user_id=current_user.id, name=name, shot=shot, training_progress=training_progress, complete_progress=complete_progress, percentage=percentage, date=date)
                    db.session.add(player)
                    db.session.commit()
                else:
                    # 處理日期為空的情況，例如傳回錯誤訊息
                    flash('Date is required for new entries.', 'danger')
                    return redirect('/schedule')

            except ValueError as e:
                # 如果無法將字串轉換為整數，進行相應的處理，例如返回錯誤消息
                flash(str(e), 'danger')
                return redirect('/schedule')

        # 重定向到顯示所有記錄的頁面
        return redirect('/schedule')
    return render_template('schedule.html', players=players)

# 查看紀錄
@app.route('/view/<int:selected_id>', methods = ['GET','POST'])
def view(selected_id):
    if g.user is None:
        return redirect(url_for('login'))  # 若 g.user 為空，導向到登入頁面
    players = Player.query.all()
    return render_template('view.html', players=players, selected_id=selected_id)


# 新增紀錄
@app.route('/add', methods = ['GET','POST'])
def add():
    if g.user is None:
        return redirect(url_for('login'))  # 若 g.user 為空，導向到登入頁面
    players = Player.query.all()
    return render_template('add.html', players=players)

# 修改紀錄
@app.route('/edit/<int:selected_id>', methods = ['GET','POST'])
def edit(selected_id):
    if g.user is None:
        return redirect(url_for('login'))  # 若 g.user 為空，導向到登入頁面
    players = Player.query.all()
    return render_template('edit.html', players=players, selected_id=selected_id)

# 刪除紀錄
@app.route('/delete/<int:selected_id>', methods = ['GET','POST'])
# @login_required
def delete(selected_id):
    # 若 g.user 為空，導向到登入頁面
    if g.user is None:
        return redirect(url_for('login'))

    players = Player.query.all()
    return render_template('delete.html', players=players, selected_id=selected_id)

@app.route('/delete_selected', methods=['POST'])
def delete_selected():
    if request.method == 'POST':
        selected_ids = request.json.get('selectedIds')
        if selected_ids:
            # 執行刪除選取資料的操作
            for selected_id in selected_ids:
                player = Player.query.get(selected_id)
                if player:
                    # 刪除資料庫中的記錄
                    db.session.delete(player)

            # 提交資料庫更改
            db.session.commit()

            # 回傳一個成功的回應
            return jsonify({'message': '所選項目已成功刪除'})

    # 如果沒有選定的ID，回傳一個錯誤回應
    return jsonify({'message': '沒有選擇要刪除的項目'}), 400


# 選擇訓練方式
@app.route('/choose', methods = ['GET','POST'])
def choose():
    return render_template('start.html')

# 影片辨識
@app.route('/video', methods = ['GET','POST'])
def video():
    return render_template('train.html')

# 根據用戶選擇進行模型訓練
def train_model(training_option, file_filename):
    if training_option == "正手長球":
        Long(file_filename)
    elif training_option == "反手長球":
        LongBackHand(file_filename)
    elif training_option == "正手小球" :
        Short(file_filename)
    elif training_option == "反手小球" :
        Short(file_filename)
    elif training_option == "正手挑球" :
        ForeHandFlick(file_filename)
    elif training_option == "反手挑球" :
        BackHandFlick(file_filename)
@app.route('/train', methods=['POST'])
def train():
    if request.method == 'POST':
        file = request.files['file']
        if file and allowed_file(file.filename):
            file_filename = secure_filename(file.filename)
            file.save(file_filename)

            training_option = request.form['training_option']
            train_model(training_option, file_filename)

    return redirect(url_for('video'))


# 及時辨識
@app.route('/realtime', methods = ['GET','POST'])
def realtime():
    return render_template('realtime.html')
def realtime_model(training_option):
    # 根據用戶選擇的訓練選項，啟動對應的模型訓練
    if training_option == "正手長球":
        subprocess.Popen(['python', 'Long.py'])
    elif training_option == "反手長球":
        subprocess.Popen(['python', 'Longbackhand.py'])
    elif training_option == "正手小球" :
        subprocess.Popen(['python', 'ForeShort.py'])
    elif training_option == "反手小球" :
        subprocess.Popen(['python', 'BackShort.py'])
    elif training_option == "正手挑球" :
        subprocess.Popen(['python', 'ForeHandFlick.py'])
    elif training_option == "反手挑球" :
        subprocess.Popen(['python', 'BackHandFlick.py'])
# 及時辨識(主程式)
@app.route('/real_Time', methods = ['GET','POST'])
def real_Time():
    if request.method == 'POST':

        training_option = request.form['training_option']   # [POST] # 使用request.form取得前端的training_option
        realtime_model(training_option)
    return redirect(url_for('realtime'))


# # 影片辨識
# @app.route('/video', methods = ['GET','POST'])
# def video():
#     return render_template('train.html')

# # 根據用戶選擇進行模型訓練
# def train_model(hand, training_option, file_filename):
#     if hand == "右手":
#         if training_option == "正手長球":
#             Long(file_filename)
#         elif training_option == "反手長球":
#             LongBackHand(file_filename)
#         elif training_option == "正手小球" :
#             Short(file_filename)
#         elif training_option == "反手小球" :
#             Short(file_filename)
#         elif training_option == "正手挑球" :
#             ForeHandFlick(file_filename)
#         elif training_option == "反手挑球" :
#             BackHandFlick(file_filename)
#     if hand == "左手":
#         if training_option == "正手長球":
#             Long(file_filename)
#         elif training_option == "反手長球":
#             LongBackHand(file_filename)
#         elif training_option == "正手小球" :
#             Short(file_filename)
#         elif training_option == "反手小球" :
#             Short(file_filename)
#         elif training_option == "正手挑球" :
#             ForeHandFlick(file_filename)
#         elif training_option == "反手挑球" :
#             BackHandFlick(file_filename)
# @app.route('/train', methods=['POST'])
# def train():
#     if request.method == 'POST':
#         file = request.files['file']
#         if file and allowed_file(file.filename):
#             file_filename = secure_filename(file.filename)
#             file.save(file_filename)

#             training_option = request.form['training_option']
#             hand = request.form['hand']
#             train_model(hand, training_option, file_filename)

#     return redirect(url_for('video'))

# # 及時辨識
# @app.route('/realtime', methods = ['GET','POST'])
# def realtime():
#     return render_template('realtime.html')

# # 建立用於處理模型訓練的函式
# def realtime_model(hand, training_option):
#     # 根據用戶選擇的訓練選項，啟動對應的模型訓練
#     if hand == "右手":
#         if training_option == "正手長球":
#             subprocess.Popen(['python', 'Long.py'])
#         elif training_option == "反手長球":
#             subprocess.Popen(['python', 'Longbackhand.py'])
#         elif training_option == "正手小球" :
#             subprocess.Popen(['python', 'ForeShort.py'])
#         elif training_option == "反手小球" :
#             subprocess.Popen(['python', 'BackShort.py'])
#         elif training_option == "正手挑球" :
#             subprocess.Popen(['python', 'ForeHandFlick.py'])
#         elif training_option == "反手挑球" :
#             subprocess.Popen(['python', 'BackHandFlick.py'])
#     if hand == "左手":
#         if training_option == "正手長球":
#             subprocess.Popen(['python', 'Long.py'])
#         elif training_option == "反手長球":
#             subprocess.Popen(['python', 'Longbackhand.py'])
#         elif training_option == "正手小球" :
#             subprocess.Popen(['python', 'ForeShort.py'])
#         elif training_option == "反手小球" :
#             subprocess.Popen(['python', 'BackShort.py'])
#         elif training_option == "正手挑球" :
#             subprocess.Popen(['python', 'ForeHandFlick.py'])
#         elif training_option == "反手挑球" :
#             subprocess.Popen(['python', 'BackHandFlick.py'])
# # 及時辨識(主程式)
# @app.route('/real_Time', methods = ['GET','POST'])
# def real_Time():
#     if request.method == 'POST':
#         training_option = request.form['training_option']   # [POST] # 使用request.form取得前端的training_option
#         hand = request.form['hand']
#         # training_option = request.args.get('training_option') #GET
#         # if hand == "右手":
#         #     realtime_model(hand, training_option)
#         realtime_model(hand,training_option)
#     return redirect(url_for('realtime'))

if __name__ == '__main__':
    app.run(host='0.0.0.0',port=5000,debug=True)